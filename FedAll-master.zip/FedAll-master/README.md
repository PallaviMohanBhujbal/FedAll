## Example

The following is an example for using FedAll

### Server

Open one terminal, and the run the following:

```
python3 server_example.py

```
### Client 1

Open another terminal, and the run the following:

```
python3 client_example_1.py

```

### Client 2

Open another terminal, and the run the following:

```
python3 client_example_2.py

```